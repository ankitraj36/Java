import java.util.Scanner;

public class PowerWithoutArithmetic {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter base and exponent
        System.out.print("Enter the base (x): ");
        int x = scanner.nextInt();
        System.out.print("Enter the exponent (y): ");
        int y = scanner.nextInt();

        // Call the method to compute x^y without using arithmetic operators
        int result = power(x, y);

        // Display the result
        System.out.println("The result of " + x + "^" + y + " is: " + result);

        // Close the scanner
        scanner.close();
    }

    // Method to compute x^y without using arithmetic operators
    public static int power(int x, int y) {
        int result = 1;

        while (y > 0) {
            // If y is odd
            if ((y & 1) == 1) {
                result = multiply(result, x); // Multiply result by x
            }

            // Square x and shift y by 1 (equivalent to dividing y by 2)
            x = multiply(x, x);
            y >>= 1; // Right shift y by 1
        }

        return result;
    }

    // Method to multiply two numbers without using the multiplication operator
    public static int multiply(int a, int b) {
        int result = 0;
        while (b > 0) {
            if ((b & 1) == 1) {
                result = add(result, a);
            }
            a <<= 1;  // Left shift a (equivalent to multiplying a by 2)
            b >>= 1;  // Right shift b (equivalent to dividing b by 2)
        }
        return result;
    }

    // Method to add two numbers without using the addition operator
    public static int add(int a, int b) {
        while (b != 0) {
            int carry = a & b;  // Carry bits
            a = a ^ b;  // Sum without carry
            b = carry << 1;  // Shift carry to the left
        }
        return a;
    }
}
