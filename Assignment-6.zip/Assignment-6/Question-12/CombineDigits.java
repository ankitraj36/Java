import java.util.Scanner;

public class CombineDigits {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the first integer number
        System.out.print("Enter the first number: ");
        int num1 = scanner.nextInt();

        // Prompt the user to enter the second integer number
        System.out.print("Enter the second number: ");
        int num2 = scanner.nextInt();

        // Call the method to create the new number
        int result = createCombinedNumber(num1, num2);

        // Display the result
        System.out.println("The combined number is: " + result);

        // Close the scanner
        scanner.close();
    }

    // Method to create the combined number
    public static int createCombinedNumber(int num1, int num2) {
        // Get the first two digits of num1
        int firstTwoDigits = num1 / 100;

        // Get the last two digits of num2
        int lastTwoDigits = num2 % 100;

        // Combine the digits to form the new number
        return firstTwoDigits * 100 + lastTwoDigits;
    }
}
