import java.util.Scanner;

public class MultiplyWithoutArithmetic {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter two integers
        System.out.print("Enter the first number (x): ");
        int x = scanner.nextInt();
        System.out.print("Enter the second number (y): ");
        int y = scanner.nextInt();

        // Call the method to compute the product without using arithmetic operators
        int result = multiply(x, y);

        // Display the result
        System.out.println("The product of " + x + " and " + y + " is: " + result);

        // Close the scanner
        scanner.close();
    }

    // Method to compute x * y without using arithmetic operators
    public static int multiply(int x, int y) {
        int result = 0;

        // Iterate through all the bits of y
        while (y > 0) {
            // If the least significant bit of y is 1
            if ((y & 1) == 1) {
                result = add(result, x);  // Add x to result
            }

            // Shift y right by 1 (equivalent to dividing y by 2)
            y >>= 1;

            // Shift x left by 1 (equivalent to multiplying x by 2)
            x <<= 1;
        }

        return result;
    }

    // Method to add two numbers without using arithmetic operators
    public static int add(int a, int b) {
        while (b != 0) {
            // Carry now contains common set bits of a and b
            int carry = a & b;

            // Sum of bits of a and b where at least one of the bits is not set
            a = a ^ b;

            // Carry is shifted by one so that adding it to a gives the required sum
            b = carry << 1;
        }
        return a;
    }
}
