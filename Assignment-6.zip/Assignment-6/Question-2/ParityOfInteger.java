import java.util.Scanner;

public class ParityOfInteger {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter an integer
        System.out.print("Enter an integer: ");
        int num = scanner.nextInt();

        // Call the method to calculate the parity
        int parity = calculateParity(num);

        // Display the result
        System.out.println("The parity of the integer " + num + " is: " + parity);

        // Close the scanner
        scanner.close();
    }

    // Method to calculate the parity of an integer
    public static int calculateParity(int num) {
        int count = 0;

        // Count the number of set bits (1s)
        while (num != 0) {
            count += num & 1; // Increment count if the least significant bit is 1
            num >>= 1;         // Right shift the number to check the next bit
        }

        // If the count of set bits is odd, return 1 (odd parity), else return 0 (even parity)
        return count % 2;
    }
}
