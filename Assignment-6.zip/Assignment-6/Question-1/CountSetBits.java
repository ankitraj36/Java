import java.util.Scanner;

public class CountSetBits {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter an integer
        System.out.print("Enter an integer: ");
        int num = scanner.nextInt();

        // Call the method to count set bits
        int count = countSetBits(num);

        // Display the result
        System.out.println("The number of set bits (1s) in the integer " + num + " is: " + count);

        // Close the scanner
        scanner.close();
    }

    // Method to count set bits (1s) in the binary representation of an integer
    public static int countSetBits(int num) {
        int count = 0;

        // Iterate through each bit of the number
        while (num != 0) {
            // Increment count if the least significant bit is 1
            count += num & 1;

            // Right shift the number by 1 to check the next bit
            num >>= 1;
        }

        return count;
    }
}
