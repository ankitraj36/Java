import java.util.Scanner;

public class ReverseBits64 {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a 64-bit integer (long)
        System.out.print("Enter a 64-bit number: ");
        long num = scanner.nextLong();

        // Call the method to reverse the bits
        long reversedNum = reverseBits(num);

        // Display the original and reversed numbers
        System.out.println("Original number: " + num);
        System.out.println("Reversed number: " + reversedNum);

        // Close the scanner
        scanner.close();
    }

    // Method to reverse the bits of a 64-bit number
    public static long reverseBits(long num) {
        long reversed = 0;
        for (int i = 0; i < 64; i++) {
            // Get the least significant bit of num
            long bit = num & 1;
            // Shift the bit to the left position in the reversed number
            reversed = (reversed << 1) | bit;
            // Right shift num to move to the next bit
            num >>= 1;
        }
        return reversed;
    }
}
