import java.util.Scanner;

public class DivideWithoutArithmetic {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter two integers x and y
        System.out.print("Enter the numerator (x): ");
        int x = scanner.nextInt();
        System.out.print("Enter the denominator (y): ");
        int y = scanner.nextInt();

        // Handle the case where y is zero
        if (y == 0) {
            System.out.println("Error: Division by zero is undefined.");
        } else {
            // Call the method to compute x / y without using arithmetic operators
            int result = divide(x, y);

            // Display the result
            System.out.println("The result of " + x + " / " + y + " is: " + result);
        }

        // Close the scanner
        scanner.close();
    }

    // Method to compute x / y using bitwise operations
    public static int divide(int x, int y) {
        int result = 0;
        int power = 31;
        int yPower = y << power; // y * 2^31 (left-shift y by 31 bits)

        // Continue until yPower becomes larger than x
        while (x >= y) {
            while (yPower > x) {
                yPower >>= 1; // Right shift yPower (equivalent to dividing by 2)
                power--;
            }
            x -= yPower; // Subtract yPower from x
            result += (1 << power); // Add 2^power to result
        }

        return result;
    }
}
