import java.util.Scanner;

public class FloatDifferenceChecker {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter two float numbers
        System.out.print("Enter the first float number: ");
        float num1 = scanner.nextFloat();

        System.out.print("Enter the second float number: ");
        float num2 = scanner.nextFloat();

        // Define epsilon (ϵ) as 0.001 (or any value < 1)
        float epsilon = 0.001f;

        // Call the method to check if the difference is less than epsilon
        if (isDifferenceLessThanEpsilon(num1, num2, epsilon)) {
            System.out.println("The difference between the two numbers is less than " + epsilon);
        } else {
            System.out.println("The difference between the two numbers is greater than or equal to " + epsilon);
        }

        // Close the scanner
        scanner.close();
    }

    // Method to check if the difference between two float numbers is less than epsilon
    public static boolean isDifferenceLessThanEpsilon(float num1, float num2, float epsilon) {
        // Calculate the absolute difference between the two numbers
        float difference = Math.abs(num1 - num2);

        // Return true if the difference is less than epsilon
        return difference < epsilon;
    }
}
