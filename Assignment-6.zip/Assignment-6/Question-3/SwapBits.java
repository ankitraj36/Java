import java.util.Scanner;

public class SwapBits {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the integer and bit positions
        System.out.print("Enter an integer: ");
        int num = scanner.nextInt();
        System.out.print("Enter the position of i: ");
        int i = scanner.nextInt();
        System.out.print("Enter the position of j: ");
        int j = scanner.nextInt();

        // Call the method to swap the bits
        int swappedNum = swapBits(num, i, j);

        // Display the result
        System.out.println("The number after swapping the bits at positions " + i + " and " + j + " is: " + swappedNum);

        // Close the scanner
        scanner.close();
    }

    // Method to swap the ith and jth bits of the number
    public static int swapBits(int num, int i, int j) {
        // Check if the bits at position i and j are different
        if (((num >> i) & 1) != ((num >> j) & 1)) {
            // If they are different, flip them
            num = num ^ (1 << i); // Flip the ith bit
            num = num ^ (1 << j); // Flip the jth bit
        }

        return num;
    }
}
