import java.util.Scanner;

public class EvenOddCheck {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();

        // Call the method to check if the number is even
        System.out.println(isEven(num));

        // Close the scanner
        scanner.close();
    }

    // Method to check if a number is even
    public static boolean isEven(int num) {
        // Return true if the number is divisible by 2, else false
        return num % 2 == 0;
    }
}
