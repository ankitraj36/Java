import java.util.Scanner;

public class PalindromeNumber {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();

        // Call the method to check if the number is a palindrome
        boolean isPalindrome = checkPalindrome(num);

        // Display the result
        if (isPalindrome) {
            System.out.println(num + " is a palindrome.");
        } else {
            System.out.println(num + " is not a palindrome.");
        }

        // Close the scanner
        scanner.close();
    }

    // Method to check if a number is a palindrome
    public static boolean checkPalindrome(int num) {
        int originalNum = num;  // Store the original number
        int reversed = 0;

        // Handle negative numbers (negative numbers are not palindromes)
        if (num < 0) {
            return false;
        }

        // Reverse the digits of the number
        while (num != 0) {
            int digit = num % 10;  // Get the last digit
            reversed = reversed * 10 + digit;  // Add the digit to the reversed number
            num /= 10;  // Remove the last digit from num
        }

        // Check if the original number is equal to the reversed number
        return originalNum == reversed;
    }
}
