import java.util.Scanner;

public class CountEvenDigits {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter an integer
        System.out.print("Enter an integer number: ");
        int num = scanner.nextInt();

        // Call the method to count even digits
        int evenDigitCount = countEvenDigits(num);

        // Display the result
        System.out.println("The number of even digits in the number is: " + evenDigitCount);

        // Close the scanner
        scanner.close();
    }

    // Method to count the number of even digits in the number
    public static int countEvenDigits(int num) {
        int count = 0;

        // Convert the number to its absolute value to handle negative numbers
        num = Math.abs(num);

        // Process each digit of the number
        while (num > 0) {
            // Get the last digit
            int digit = num % 10;

            // Check if the digit is even
            if (digit % 2 == 0) {
                count++;
            }

            // Remove the last digit from the number
            num /= 10;
        }

        return count;
    }
}
