import java.util.Scanner;

public class ReverseNumber {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a number
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();

        // Call the method to reverse the number
        int reversedNum = reverse(num);

        // Display the reversed number
        System.out.println("Reversed number: " + reversedNum);

        // Close the scanner
        scanner.close();
    }

    // Method to reverse the number
    public static int reverse(int num) {
        // Variable to store the reversed number
        int reversed = 0;

        // Handle the case when the number is negative
        boolean isNegative = num < 0;
        if (isNegative) {
            num = -num;  // Make the number positive for easier reversal
        }

        // Reverse the digits of the number
        while (num != 0) {
            // Get the last digit
            int digit = num % 10;

            // Add the digit to the reversed number
            reversed = reversed * 10 + digit;

            // Remove the last digit from num
            num /= 10;
        }

        // If the number was negative, return the negative reversed number
        if (isNegative) {
            reversed = -reversed;
        }

        return reversed;
    }
}
