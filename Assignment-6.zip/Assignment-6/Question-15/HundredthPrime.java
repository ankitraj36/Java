public class HundredthPrime {
    public static void main(String[] args) {
        // Variable to track the count of prime numbers
        int count = 0;

        // Variable to store the current number to check
        int num = 2;

        // Loop until the 100th prime is found
        while (count < 100) {
            if (isPrime(num)) {
                count++;  // Increment the count when a prime is found
            }
            num++;  // Check the next number
        }

        // Print the 100th prime number
        System.out.println("The 100th prime number is: " + (num - 1));
    }

    // Method to check if a number is prime
    public static boolean isPrime(int num) {
        // Numbers less than 2 are not prime
        if (num <= 1) {
            return false;
        }

        // Check for divisibility from 2 to the square root of num
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                return false;  // num is divisible by i, so it's not prime
            }
        }

        // If no divisors are found, the number is prime
        return true;
    }
}
