import java.util.Scanner;

public class DigitFrequency {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter an integer number
        System.out.print("Enter an integer number: ");
        int num = scanner.nextInt();

        // Call the method to count the frequency of digits
        int[] frequency = countDigitFrequency(num);

        // Display the frequency of each digit
        System.out.println("Frequency of each digit:");
        for (int i = 0; i < frequency.length; i++) {
            System.out.println(i + ": " + frequency[i]);
        }

        // Close the scanner
        scanner.close();
    }

    // Method to count the frequency of each digit in a number
    public static int[] countDigitFrequency(int num) {
        // Create an array to store the frequency of digits from 0 to 9
        int[] frequency = new int[10];

        // Handle negative numbers by converting them to positive
        num = Math.abs(num);

        // Extract each digit and count its occurrence
        while (num > 0) {
            int digit = num % 10;  // Get the last digit
            frequency[digit]++;    // Increment the count for this digit
            num /= 10;             // Remove the last digit from the number
        }

        return frequency;
    }
}
