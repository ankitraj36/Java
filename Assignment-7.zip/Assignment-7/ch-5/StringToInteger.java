import java.util.Scanner;

public class StringToInteger {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read integer as a string
        System.out.print("Enter an integer: ");
        String input = scanner.nextLine();

        try {
            // Convert the string to an Integer object
            Integer integerObj = Integer.valueOf(input);

            // Output the Integer object
            System.out.println("Integer object: " + integerObj);
        } catch (NumberFormatException e) {
            System.out.println("Invalid input! Please enter a valid integer.");
        }

        scanner.close();
    }
}
