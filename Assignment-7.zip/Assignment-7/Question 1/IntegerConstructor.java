public class IntegerConstructor {
    public static void main(String[] args) {
        int num = 69; // Primitive integer
        Integer integerObj = Integer.valueOf(num); // Preferred way to create an Integer object

        System.out.println("Integer object (Using valueOf): " + integerObj);
    }
}
