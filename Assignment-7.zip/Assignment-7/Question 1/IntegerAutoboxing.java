public class IntegerAutoboxing {
    public static void main(String[] args) {
        int num = 42; // Primitive integer
        Integer integerObj = num; // Autoboxing

        System.out.println("Integer object (Autoboxing): " + integerObj);
    }
}
