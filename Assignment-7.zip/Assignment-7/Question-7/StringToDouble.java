import java.util.Scanner;

public class StringToDouble {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a double value as a string
        System.out.print("Enter a double value as a string: ");
        String doubleString = scanner.nextLine();

        try {
            // Convert the string to a Double object
            Double doubleValue = Double.valueOf(doubleString);

            // Display the Double object
            System.out.println("The Double object is: " + doubleValue);
        } catch (NumberFormatException e) {
            // Handle invalid double input
            System.out.println("Invalid input. Please enter a valid double value.");
        }

        // Close the scanner
        scanner.close();
    }
}
