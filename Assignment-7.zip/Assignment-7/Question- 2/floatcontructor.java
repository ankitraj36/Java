public class floatcontructor {
     public static void main(String[] args) {
        float num = 79f;
        Float intobjfloat = Float.valueOf(num);
        System.out.println("FLOAT (CONSTRUCTOR ) IS " + intobjfloat);
     }
}
