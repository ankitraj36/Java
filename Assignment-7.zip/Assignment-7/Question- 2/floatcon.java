public class floatcon {
    public static void main(String[] args) {
        float num = 56f;
        Float objFloat = num;
        System.out.println("FLOAT NUMBER IS AUTOBOXING " + objFloat);
    }
}
