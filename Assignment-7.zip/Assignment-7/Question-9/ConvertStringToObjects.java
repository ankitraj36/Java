import java.util.Scanner;

public class ConvertStringToObjects {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Read an int as a string and convert to Integer object
        System.out.print("Enter an int value as a string: ");
        String intString = scanner.nextLine();
        Integer intValue = Integer.valueOf(intString);
        System.out.println("Integer object: " + intValue);

        // Read a float as a string and convert to Float object
        System.out.print("Enter a float value as a string: ");
        String floatString = scanner.nextLine();
        Float floatValue = Float.valueOf(floatString);
        System.out.println("Float object: " + floatValue);

        // Read a double as a string and convert to Double object
        System.out.print("Enter a double value as a string: ");
        String doubleString = scanner.nextLine();
        Double doubleValue = Double.valueOf(doubleString);
        System.out.println("Double object: " + doubleValue);

        // Read a boolean as a string and convert to Boolean object
        System.out.print("Enter a boolean value (true/false) as a string: ");
        String booleanString = scanner.nextLine();
        Boolean booleanValue = Boolean.valueOf(booleanString);
        System.out.println("Boolean object: " + booleanValue);

        // Close the scanner
        scanner.close();
    }
}
