import java.util.Scanner;

public class StringToDoubleBaseType {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a double value as a string
        System.out.print("Enter a double value as a string: ");
        String doubleString = scanner.nextLine();

        try {
            // Convert the string to a double base type
            double doubleValue = Double.parseDouble(doubleString);

            // Display the double value
            System.out.println("The double base type is: " + doubleValue);
        } catch (NumberFormatException e) {
            // Handle invalid input
            System.out.println("Invalid input. Please enter a valid double value.");
        }

        // Close the scanner
        scanner.close();
    }
}
