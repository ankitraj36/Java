import java.util.Scanner;

public class StringToFloat {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a float value as a string
        System.out.print("Enter a float value as a string: ");
        String floatString = scanner.nextLine();

        try {
            // Convert the string to a Float object
            Float floatValue = Float.valueOf(floatString);

            // Display the Float object
            System.out.println("The Float object is: " + floatValue);
        } catch (NumberFormatException e) {
            // Handle invalid float input
            System.out.println("Invalid input. Please enter a valid float value.");
        }

        // Close the scanner
        scanner.close();
    }
}
