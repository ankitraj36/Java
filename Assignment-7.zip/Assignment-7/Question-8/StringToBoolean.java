import java.util.Scanner;

public class StringToBoolean {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a boolean value as a string
        System.out.print("Enter a boolean value (true/false): ");
        String booleanString = scanner.nextLine();

        // Convert the string to a Boolean object
        Boolean booleanValue = Boolean.valueOf(booleanString);

        // Display the Boolean object
        System.out.println("The Boolean object is: " + booleanValue);

        // Close the scanner
        scanner.close();
    }
}
