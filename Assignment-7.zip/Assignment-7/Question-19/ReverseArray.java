import java.util.Scanner;

public class ReverseArray {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the number of elements in the array
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();

        // Initialize the array
        int[] array = new int[n];

        // Prompt the user to enter the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        // Reverse the array
        int start = 0, end = n - 1;
        while (start < end) {
            // Swap the elements at 'start' and 'end' positions
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;

            // Move the 'start' pointer forward and 'end' pointer backward
            start++;
            end--;
        }

        // Display the reversed array
        System.out.println("The reversed array is:");
        for (int i = 0; i < n; i++) {
            System.out.print(array[i] + " ");
        }

        // Close the scanner
        scanner.close();
    }
}

