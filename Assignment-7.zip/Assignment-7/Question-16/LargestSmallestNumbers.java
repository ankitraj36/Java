import java.util.Scanner;

public class LargestSmallestNumbers {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Initialize variables to track the largest and smallest numbers
        int largest = Integer.MIN_VALUE;  // Smallest possible integer
        int smallest = Integer.MAX_VALUE; // Largest possible integer

        // Variable to control the loop
        String continueInput;

        // Loop to take user input until they decide to stop
        do {
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();

            // Update the largest and smallest numbers
            if (number > largest) {
                largest = number;
            }
            if (number < smallest) {
                smallest = number;
            }

            // Ask the user if they want to enter another number
            System.out.print("Do you want to enter another number? (yes/no): ");
            continueInput = scanner.next();

        } while (continueInput.equalsIgnoreCase("yes"));

        // Display the largest and smallest numbers
        System.out.println("The largest number entered is: " + largest);
        System.out.println("The smallest number entered is: " + smallest);

        // Close the scanner
        scanner.close();
    }
}
