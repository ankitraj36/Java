public class doubleauto {
       public static void main(String[] args) {
        double number = 895.23;
        Double autonum = number;
        System.out.println("Double autoboxing is " + autonum);
       }    
}
