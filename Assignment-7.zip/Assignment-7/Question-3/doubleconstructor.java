

public class doubleconstructor {
  public static void main(String[] args) {
    double num = 1322.332;
    Double newnum = Double.valueOf(num);
    System.out.println("Double the autoboxing is " + newnum);
  }  
}
