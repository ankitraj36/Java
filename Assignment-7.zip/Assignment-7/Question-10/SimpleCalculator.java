import java.util.Scanner;

public class SimpleCalculator {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter an expression
        System.out.print("Enter a simple expression (e.g., 123+345): ");
        String input = scanner.nextLine();

        // Parse the input string
        char operator = 0;
        int operatorIndex = -1;

        // Identify the operator and its index
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                operator = ch;
                operatorIndex = i;
                break;
            }
        }

        // Validate the input
        if (operatorIndex == -1) {
            System.out.println("Invalid input. Please enter a valid expression.");
            return;
        }

        // Split the numbers and convert them to primitive types
        String leftOperand = input.substring(0, operatorIndex);
        String rightOperand = input.substring(operatorIndex + 1);
        try {
            int num1 = Integer.parseInt(leftOperand);
            int num2 = Integer.parseInt(rightOperand);

            // Perform the operation
            switch (operator) {
                case '+':
                    System.out.println("Sum = " + (num1 + num2));
                    break;
                case '-':
                    System.out.println("Difference = " + (num1 - num2));
                    break;
                case '*':
                    System.out.println("Product = " + (num1 * num2));
                    break;
                case '/':
                    if (num2 != 0) {
                        System.out.println("Quotient = " + (num1 / num2));
                    } else {
                        System.out.println("Error: Division by zero.");
                    }
                    break;
                default:
                    System.out.println("Invalid operator.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format. Please enter valid integers.");
        }

        // Close the scanner
        scanner.close();
    }
}
