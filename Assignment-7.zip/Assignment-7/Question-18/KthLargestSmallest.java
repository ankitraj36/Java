import java.util.Arrays;
import java.util.Scanner;

public class KthLargestSmallest {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the number of elements in the array
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();

        // Initialize the array
        int[] array = new int[n];

        // Prompt the user to enter the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        // Prompt the user to enter the value of K
        System.out.print("Enter the value of K: ");
        int K = scanner.nextInt();

        // Check if K is valid
        if (K > n || K <= 0) {
            System.out.println("Invalid value of K. It should be between 1 and " + n);
        } else {
            // Sort the array
            Arrays.sort(array);

            // Find the Kth smallest and Kth largest
            int kthSmallest = array[K - 1];
            int kthLargest = array[n - K];

            // Display the results
            System.out.println("The " + K + "th smallest element is: " + kthSmallest);
            System.out.println("The " + K + "th largest element is: " + kthLargest);
        }

        // Close the scanner
        scanner.close();
    }
}
