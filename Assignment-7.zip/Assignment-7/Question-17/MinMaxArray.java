import java.util.Scanner;

public class MinMaxArray {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the size of the array
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();

        // Initialize the array
        int[] array = new int[n];

        // Prompt the user to enter the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        // Initialize variables for the minimum and maximum values
        int min = array[0];
        int max = array[0];

        // Traverse the array to find the minimum and maximum elements
        for (int i = 1; i < n; i++) {
            if (array[i] < min) {
                min = array[i]; // Update min if current element is smaller
            }
            if (array[i] > max) {
                max = array[i]; // Update max if current element is larger
            }
        }

        // Display the results
        System.out.println("The minimum element in the array is: " + min);
        System.out.println("The maximum element in the array is: " + max);

        // Close the scanner
        scanner.close();
    }
}
