import java.util.Scanner;

public class StringToIntBaseType {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter an integer as a string
        System.out.print("Enter an integer value as a string: ");
        String intString = scanner.nextLine();

        try {
            // Convert the string to an int base type
            int intValue = Integer.parseInt(intString);

            // Display the int value
            System.out.println("The int base type is: " + intValue);
        } catch (NumberFormatException e) {
            // Handle invalid input
            System.out.println("Invalid input. Please enter a valid integer value.");
        }

        // Close the scanner
        scanner.close();
    }
}
