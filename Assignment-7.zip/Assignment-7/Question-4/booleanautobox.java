public class booleanautobox {

    public static void main(String[] args) {
        boolean flag = true;
        Boolean newBoolean = flag;
        System.out.println("Boolean object (AUTOBOXING) is " + newBoolean);
    }
}