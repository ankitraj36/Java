import java.util.Scanner;

public class SeriesSum {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to input n
        System.out.print("Enter a positive integer n: ");
        int n = scanner.nextInt();

        // Validate input
        if (n <= 0) {
            System.out.println("Please enter a positive integer greater than 0.");
        } else {
            double sum = 0.0;

            // Calculate the sum of the series
            for (int i = 1; i <= n; i++) {
                sum += 1.0 / i;
            }

            // Display the result
            System.out.printf("The sum of the series up to 1/%d is: %.5f%n", n, sum);
        }

        // Close the scanner
        scanner.close();
    }
}
